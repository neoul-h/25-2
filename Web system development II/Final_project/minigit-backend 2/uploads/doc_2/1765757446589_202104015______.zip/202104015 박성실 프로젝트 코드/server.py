import socket
import threading

HOST = "0.0.0.0"
PORT = 5000

# 서버 상태 저장
clients = {}  # {sock: username}
todos = []    # {"id": int, "user": str, "text": str, "status": str}
next_id = 1

lock = threading.Lock()


# ────────────────────────────────────────────────
# 공용 함수 (송신, 브로드캐스트, 직렬화)
# ────────────────────────────────────────────────

def send(sock, msg):
    """한 줄 메시지를 클라이언트로 전송."""
    try:
        sock.sendall((msg + "\n").encode("utf-8"))
    except:
        pass


def broadcast(msg, exclude=None):
    """전체 클라이언트에게 메시지 전송."""
    with lock:
        dead = []
        for s in clients:
            if s is not exclude:
                try:
                    send(s, msg)
                except:
                    dead.append(s)
        for s in dead:
            clients.pop(s, None)


def serialize_todos():
    """todo 리스트를 프로토콜 규격 문자열로 변환."""
    if not todos:
        return "EMPTY"
    result = []
    for t in todos:
        text = t["text"].replace("|", " ").replace(";", " ")
        result.append(f'{t["id"]}|{t["user"]}|{t["status"]}|{text}')
    return ";".join(result)


def sync_all():
    """모든 사용자에게 SYNC 메시지 전송."""
    payload = serialize_todos()
    broadcast(f"SYNC:SERVER:{payload}")
    

# ────────────────────────────────────────────────
# 프로토콜 핸들러
# ────────────────────────────────────────────────

def handle_login(sock, parts):
    """LOGIN:username"""
    if len(parts) < 2:
        send(sock, "LOGIN_RESULT:FAIL:NO_NAME")
        return

    username = parts[1].strip()
    if not username:
        send(sock, "LOGIN_RESULT:FAIL:EMPTY")
        return

    # 중복 체크
    with lock:
        for u in clients.values():
            if u == username:
                send(sock, "LOGIN_RESULT:FAIL:DUPLICATE")
                return

        clients[sock] = username

    print(f"[LOGIN] {username}")
    send(sock, "LOGIN_RESULT:SUCCESS")

    # 접속한 사용자에게 현재 목록 전달
    send(sock, f"SYNC:SERVER:{serialize_todos()}")

    # 다른 사용자에게 접속 알림
    broadcast(f"EVENT:{username}:LOGIN", exclude=sock)


def handle_add(sock, parts):
    """ADD:user:text"""
    if len(parts) < 3:
        send(sock, "ERROR:BAD_ADD")
        return

    user = parts[1]
    text = ":".join(parts[2:]).strip()

    if not text:
        send(sock, "ERROR:EMPTY_TEXT")
        return

    global next_id
    with lock:
        todos.append({"id": next_id, "user": user, "text": text, "status": "진행중"})
        next_id += 1

    print(f"[ADD] {user}: {text}")
    sync_all()


def handle_delete(sock, parts):
    """DELETE:user:id=번호"""
    if len(parts) < 3 or not parts[2].startswith("id="):
        send(sock, "ERROR:BAD_DELETE")
        return

    try:
        target = int(parts[2][3:])
    except:
        send(sock, "ERROR:BAD_ID")
        return

    removed = False
    with lock:
        for i, t in enumerate(todos):
            if t["id"] == target:
                todos.pop(i)
                removed = True
                break

    if not removed:
        send(sock, "ERROR:NOT_FOUND")
    else:
        print(f"[DELETE] id={target}")
        sync_all()


def handle_update(sock, parts):
    """UPDATE:user:id=번호:상태"""
    if len(parts) < 4:
        send(sock, "ERROR:BAD_UPDATE")
        return

    if not parts[2].startswith("id="):
        send(sock, "ERROR:BAD_ID")
        return

    try:
        target = int(parts[2][3:])
    except:
        send(sock, "ERROR:BAD_ID")
        return

    new_status = parts[3].strip()
    updated = False

    with lock:
        for t in todos:
            if t["id"] == target:
                t["status"] = new_status
                updated = True
                break

    if not updated:
        send(sock, "ERROR:NOT_FOUND")
    else:
        print(f"[UPDATE] id={target} → {new_status}")
        sync_all()


def handle_list(sock, parts):
    """LIST:user"""
    payload = serialize_todos()
    send(sock, f"LIST_RESULT:{payload}")


def handle_logout(sock, parts):
    """LOGOUT:user"""
    user = clients.get(sock, None)
    if user:
        print(f"[LOGOUT] {user}")
        broadcast(f"EVENT:{user}:LOGOUT", exclude=sock)
    send(sock, "BYE")
    return False  # 연결 종료 신호


# ────────────────────────────────────────────────
# 프로토콜 매핑
# ────────────────────────────────────────────────

COMMANDS = {
    "LOGIN": handle_login,
    "ADD": handle_add,
    "DELETE": handle_delete,
    "UPDATE": handle_update,
    "LIST": handle_list,
    "LOGOUT": handle_logout
}


# ────────────────────────────────────────────────
# 클라이언트 스레드
# ────────────────────────────────────────────────

def client_thread(sock, addr):
    print(f"[연결] {addr}")

    buffer = ""
    try:
        while True:
            data = sock.recv(1024)
            if not data:
                break

            buffer += data.decode("utf-8")

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.strip()

                if not line:
                    continue

                parts = line.split(":")

                cmd = parts[0].upper()
                handler = COMMANDS.get(cmd)

                if handler is None:
                    send(sock, "ERROR:UNKNOWN_COMMAND")
                    continue

                # 로그 표시
                print(f"[RECV] {line}")

                keep = handler(sock, parts)
                if keep is False:
                    return

    except:
        pass

    finally:
        user = clients.pop(sock, None)
        if user:
            broadcast(f"EVENT:{user}:LOGOUT")
        try:
            sock.close()
        except:
            pass
        print(f"[연결 종료] {addr}")


# ────────────────────────────────────────────────
# 서버 메인
# ────────────────────────────────────────────────

def main():
    print("*************************")
    print("   TODO Sync Server")
    print("   Protocol-Based")
    print("*************************")
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen()

        print(f"[서버 시작] {HOST}:{PORT}")

        while True:
            client_sock, addr = s.accept()
            threading.Thread(target=client_thread, args=(client_sock, addr), daemon=True).start()


if __name__ == "__main__":
    main()
