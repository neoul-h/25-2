import socket
import threading
import sys

def send(sock, msg):
    try:
        sock.sendall((msg + "\n").encode("utf-8"))
    except:
        pass


# ────────────────────────────────────────────────
# 서버 메시지 처리
# ────────────────────────────────────────────────

def parse_todos(payload):
    if payload == "EMPTY":
        return []
    result = []
    items = payload.split(";")
    for item in items:
        try:
            tid, user, status, text = item.split("|")
            result.append({
                "id": int(tid),
                "user": user,
                "status": status,
                "text": text
            })
        except:
            continue
    return result


def show_todos(todos):
    print("\n[TODO 목록]")
    if not todos:
        print("(비어 있음)")
        return
    print("-" * 40)
    for t in todos:
        print(f"#{t['id']:02d} | {t['user']:8} | {t['status']:6} | {t['text']}")
    print("-" * 40)


def handle_server_message(line):
    if line.startswith("LOGIN_RESULT:"):
        print("[로그인 결과]", line)
        return

    if line.startswith("SYNC:SERVER:"):
        payload = line[len("SYNC:SERVER:"):]
        todos = parse_todos(payload)
        show_todos(todos)
        return

    if line.startswith("LIST_RESULT:"):
        payload = line[len("LIST_RESULT:"):]
        todos = parse_todos(payload)
        show_todos(todos)
        return

    if line.startswith("EVENT:"):
        print("[이벤트]", line)
        return

    if line.startswith("ERROR:"):
        print("[에러]", line)
        return

    if line == "BYE":
        print("[서버] 정상 종료")
        sys.exit(0)

    print("[서버 메시지]", line)


def recv_thread(sock):
    buffer = ""
    try:
        while True:
            data = sock.recv(1024)
            if not data:
                break
            buffer += data.decode("utf-8")
            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                handle_server_message(line.strip())
    except:
        pass
    finally:
        sys.exit(0)


# ────────────────────────────────────────────────
# 메인 클라이언트
# ────────────────────────────────────────────────

def main():
    print("*************************")
    print("   TODO Sync Client")
    print("   Protocol-Based")
    print("*************************")

    host = input("서버 IP (기본 127.0.0.1): ").strip() or "127.0.0.1"
    port = 5000

    sock = socket.socket()
    sock.connect((host, port))

    threading.Thread(target=recv_thread, args=(sock,), daemon=True).start()

    user = input("닉네임 입력: ").strip()
    send(sock, f"LOGIN:{user}")

    print("\n[명령어 안내]")
    print(" add 내용    → 작업 추가")
    print(" del id      → 작업 삭제")
    print(" done id     → 상태 완료")
    print(" prog id     → 상태 진행중")
    print(" list        → 목록 요청")
    print(" logout      → 종료")

    while True:
        cmd = input("> ").strip()
        if not cmd:
            continue

        if cmd == "logout":
            send(sock, f"LOGOUT:{user}")
            break

        if cmd.startswith("add "):
            text = cmd[4:].strip()
            send(sock, f"ADD:{user}:{text}")
            continue

        if cmd.startswith("del "):
            tid = cmd[4:].strip()
            send(sock, f"DELETE:{user}:id={tid}")
            continue

        if cmd.startswith("done "):
            tid = cmd[5:].strip()
            send(sock, f"UPDATE:{user}:id={tid}:완료")
            continue

        if cmd.startswith("prog "):
            tid = cmd[5:].strip()
            send(sock, f"UPDATE:{user}:id={tid}:진행중")
            continue

        if cmd == "list":
            send(sock, f"LIST:{user}")
            continue

        print("[안내] 잘못된 명령입니다.")


if __name__ == "__main__":
    main()
