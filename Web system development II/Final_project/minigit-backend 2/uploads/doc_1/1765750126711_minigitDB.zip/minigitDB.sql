-- MiniGit 프로젝트용 데이터베이스 생성
CREATE DATABASE minigit_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE minigit_db;


-- ================================================================
-- users : MiniGit 사용자의 기본 정보를 저장하는 테이블
-- - username : 로그인 ID (중복 불가)
-- - password : 비밀번호 (과제용 → 평문도 허용)
-- - name     : 사용자 실명 또는 닉네임
-- 이 테이블의 id는 모든 문서/프로젝트/버전의 '작성자', '담당자' 등에 참조됨
-- ================================================================
CREATE TABLE users (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  username     VARCHAR(50) NOT NULL UNIQUE,
  password     VARCHAR(255) NOT NULL,
  name         VARCHAR(50) NOT NULL,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- =========================================================================
-- projects : 프로젝트(=GitHub Repository 역할)
-- - owner_id          : 프로젝트를 만든 사람
-- - due_at            : 과제 마감 시간(Assignment 기능)
-- - final_version_id  : 마감 시 저장되는 '마감본' 버전 스냅샷
-- 교수/팀원이 프로젝트 단위로 문서 및 버전들을 관리하는 구조의 최상위 엔티티
-- =========================================================================
CREATE TABLE projects (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  name              VARCHAR(100) NOT NULL,
  description       TEXT,
  owner_id          INT NOT NULL,
  due_at            DATETIME NULL,
  final_version_id  INT NULL,
  created_at        DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_projects_owner
    FOREIGN KEY (owner_id) REFERENCES users(id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ==========================================================================
-- project_members : 프로젝트와 사용자 간의 N:N 관계를 관리
-- - 하나의 프로젝트에 여러 팀원이 참여 가능
-- - 하나의 유저는 여러 프로젝트에 참여 가능
-- - role : 팀장에서 일반 멤버까지 역할 구분 가능
-- - UNIQUE(project_id, user_id) → 중복 참여 방지
-- ==========================================================================
CREATE TABLE project_members (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  project_id   INT NOT NULL,
  user_id      INT NOT NULL,
  role         VARCHAR(20) DEFAULT 'member',
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_pm_project
    FOREIGN KEY (project_id) REFERENCES projects(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_pm_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE,

  CONSTRAINT uq_pm UNIQUE (project_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ==========================================================================
-- tasks : 프로젝트의 할 일(Task) 목록
-- - project_id : 어떤 프로젝트의 Task인지
-- - assignee_id : 담당자 (없으면 NULL)
-- - status : todo / doing / done
-- Task는 문서 버전(document_versions)과 연결되어
-- "어떤 커밋이 어떤 작업을 해결했는지" 자동 추적 가능
-- ==========================================================================
CREATE TABLE tasks (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  project_id  INT NOT NULL,
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  status      VARCHAR(20) DEFAULT 'todo',
  assignee_id INT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_tasks_project
    FOREIGN KEY (project_id) REFERENCES projects(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_tasks_assignee
    FOREIGN KEY (assignee_id) REFERENCES users(id)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ==========================================================================
-- documents : 프로젝트 안에 포함된 문서(자료/파일/보고서)
-- - project_id : 어떤 프로젝트의 문서인지
-- - owner_id   : 문서를 처음 생성한 사람
-- - current_version_id : 현재 최신 버전 ID (편의 기능)
-- 문서는 여러 개의 버전(document_versions)을 가짐
-- ==========================================================================
CREATE TABLE documents (
  id                 INT AUTO_INCREMENT PRIMARY KEY,
  project_id         INT NOT NULL,
  title              VARCHAR(255) NOT NULL,
  description        TEXT,
  owner_id           INT NOT NULL,
  current_version_id INT NULL,
  created_at         DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT fk_docs_project
    FOREIGN KEY (project_id) REFERENCES projects(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_docs_owner
    FOREIGN KEY (owner_id) REFERENCES users(id)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ==========================================================================
-- document_versions : 문서의 버전(커밋 기록)
-- - version_no  : 문서별 버전 번호 (1,2,3...)
-- - author_id   : 버전 작성자
-- - content     : 문서 내용 또는 설명
-- - change_note : 변경 요약 (커밋 메시지)
-- - learned     : 이번 커밋에서 배운 점
-- - problem     : 문제점 및 해결 과정
-- - todo        : 앞으로 할 일
-- - task_id     : 어떤 Task를 해결하는 커밋인지
-- - lines_added / lines_deleted : 기여도 통계용
-- MiniGit의 핵심 기능을 담당하는 테이블
-- ==========================================================================
CREATE TABLE document_versions (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  document_id   INT NOT NULL,
  version_no    INT NOT NULL,
  author_id     INT NOT NULL,
  content       TEXT,
  change_note   TEXT,
  learned       TEXT,
  problem       TEXT,
  todo          TEXT,
  task_id       INT NULL,
  lines_added   INT DEFAULT 0,
  lines_deleted INT DEFAULT 0,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_dv_doc
    FOREIGN KEY (document_id) REFERENCES documents(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_dv_author
    FOREIGN KEY (author_id) REFERENCES users(id)
    ON DELETE CASCADE,

  CONSTRAINT fk_dv_task
    FOREIGN KEY (task_id) REFERENCES tasks(id)
    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ===================================================================
-- documents.current_version_id → document_versions(id)
-- projects.final_version_id    → document_versions(id)
-- (편의 기능이며 없어도 무방하지만 있으면 더 깔끔함)
-- ===================================================================

ALTER TABLE documents
  ADD CONSTRAINT fk_docs_current_version
    FOREIGN KEY (current_version_id) REFERENCES document_versions(id)
    ON DELETE SET NULL;

ALTER TABLE projects
  ADD CONSTRAINT fk_projects_final_version
    FOREIGN KEY (final_version_id) REFERENCES document_versions(id)
    ON DELETE SET NULL;
