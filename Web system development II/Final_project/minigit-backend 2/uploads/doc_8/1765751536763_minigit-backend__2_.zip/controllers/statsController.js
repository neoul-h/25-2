// controllers/statsController.js
// 통계 / 기여도 분석용 쿼리

const pool = require('../db');

// 멤버별 기여도 통계
exports.getContributions = async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const conn = await pool.getConnection();

    try {
      const [rows] = await conn.query(
        `SELECT u.id AS user_id,
                u.name,
                COUNT(v.id) AS commit_count,
                COALESCE(SUM(v.lines_added), 0) AS lines_added,
                COALESCE(SUM(v.lines_deleted), 0) AS lines_deleted
         FROM project_members pm
         JOIN users u ON u.id = pm.user_id
         LEFT JOIN documents d ON d.project_id = pm.project_id
         LEFT JOIN document_versions v ON v.document_id = d.id
                                      AND v.author_id = u.id
         WHERE pm.project_id = ?
         GROUP BY u.id, u.name
         ORDER BY commit_count DESC`,
        [projectId]
      );

      res.json({ contributions: rows });
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error('getContributions error:', err);
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

// Task 상태 통계
exports.getTaskStatusStats = async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const conn = await pool.getConnection();

    try {
      const [rows] = await conn.query(
        `SELECT status, COUNT(*) AS count
         FROM tasks
         WHERE project_id = ?
         GROUP BY status`,
        [projectId]
      );

      res.json({ task_status_stats: rows });
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error('getTaskStatusStats error:', err);
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

// 일자별 커밋 수
exports.getDailyCommits = async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const conn = await pool.getConnection();

    try {
      const [rows] = await conn.query(
        `SELECT DATE(v.created_at) AS date,
                COUNT(v.id) AS commit_count
         FROM documents d
         JOIN document_versions v ON v.document_id = d.id
         WHERE d.project_id = ?
         GROUP BY DATE(v.created_at)
         ORDER BY date ASC`,
        [projectId]
      );

      res.json({ daily_commits: rows });
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error('getDailyCommits error:', err);
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

// 프로젝트 전체 요약
exports.getProjectSummary = async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const conn = await pool.getConnection();

    try {
      const [[project]] = await conn.query(
        'SELECT * FROM projects WHERE id = ?',
        [projectId]
      );

      if (!project) {
        return res.status(404).json({ message: '프로젝트를 찾을 수 없습니다.' });
      }

      const [[docCount]] = await conn.query(
        'SELECT COUNT(*) AS doc_count FROM documents WHERE project_id = ?',
        [projectId]
      );

      const [[versionCount]] = await conn.query(
        `SELECT COUNT(*) AS version_count
         FROM documents d
         JOIN document_versions v ON v.document_id = d.id
         WHERE d.project_id = ?`,
        [projectId]
      );

      const [[memberCount]] = await conn.query(
        'SELECT COUNT(*) AS member_count FROM project_members WHERE project_id = ?',
        [projectId]
      );

      res.json({
        project,
        summary: {
          documents: docCount.doc_count,
          versions: versionCount.version_count,
          members: memberCount.member_count,
        },
      });
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error('getProjectSummary error:', err);
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};

// 사용자 기준 참여 프로젝트 및 커밋 수
exports.getUserProjectStats = async (req, res) => {
  try {
    const userId = req.params.userId;
    const conn = await pool.getConnection();

    try {
      const [rows] = await conn.query(
        `SELECT p.id AS project_id,
                p.name AS project_name,
                COUNT(v.id) AS commit_count
         FROM project_members pm
         JOIN projects p ON p.id = pm.project_id
         LEFT JOIN documents d ON d.project_id = p.id
         LEFT JOIN document_versions v ON v.document_id = d.id
                                      AND v.author_id = pm.user_id
         WHERE pm.user_id = ?
         GROUP BY p.id, p.name
         ORDER BY p.created_at DESC`,
        [userId]
      );

      res.json({ projects: rows });
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error('getUserProjectStats error:', err);
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
};
