// middlewares/auth.js
const jwt = require("jsonwebtoken");

function authRequired(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith("Bearer ")) {
    return res.status(401).json({ message: "인증이 필요합니다." });
  }

  const token = h.slice(7);
  try {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
      return res.status(500).json({ message: "서버 설정 오류(JWT_SECRET 누락)" });
    }
    // { userId, username, iat, exp }
    req.user = jwt.verify(token, secret);
    next();
  } catch (e) {
    return res.status(401).json({ message: "토큰이 만료되었거나 유효하지 않습니다." });
  }
}

module.exports = { authRequired };
