// server.js
// MiniGit 백엔드 + 정적 UI 서버 진입점

const express = require("express");
const dotenv = require("dotenv");
const path = require("path");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// JSON 파싱 미들웨어
app.use(express.json());

// 정적 파일(public 폴더) 서빙
app.use(express.static(path.join(__dirname, "public")));

// ✅ 업로드 파일 정적 제공 (미리보기/다운로드용)
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// 라우터 불러오기
const authRouter = require("./routes/auth");
const projectsRouter = require("./routes/projects");
const documentsRouter = require("./routes/documents");
const versionsRouter = require("./routes/versions");
const statsRouter = require("./routes/stats");
const tasksRouter = require("./routes/tasks");

const { authRequired } = require("./middlewares/auth");

// 라우터 연결
app.use("/auth", authRouter);

// ✅ 테스트용 유저목록만 보호 (프론트 영향 최소)
app.use("/auth/users", authRequired);

app.use("/projects", projectsRouter);
app.use("/documents", documentsRouter);
app.use("/versions", versionsRouter);
app.use("/tasks", tasksRouter);
app.use("/stats", statsRouter);

// 기본 라우트
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// 서버 실행
app.listen(PORT, () => {
  console.log(`🚀 MiniGit server running on port ${PORT}`);
});
