// public/app.js
// ✅ list 아이템 우측: ✎ 편집 + 🗑 삭제 버튼
// ✅ 프로젝트/문서/태스크 수정 UI (오른쪽 detail 패널에서)
// ✅ 버전 업로드(multer): FormData + task 필수 + 미리보기/다운로드

const DEFAULT_API_PORT = "3000";
const API_BASE =
  window.location.port && window.location.port !== DEFAULT_API_PORT
    ? `http://${window.location.hostname}:${DEFAULT_API_PORT}`
    : "";

// ---------------------- State ----------------------
const state = {
  user: loadUser(),
  token: loadToken(),
  currentView: "projects",
  projects: [],
  currentProject: null,
  projectMembers: [],
  documents: [],
  currentDocument: null,
  versions: [],
  tasks: [],
};

// ---------------------- DOM Helpers ----------------------
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function safeText(el, text) { if (el) el.textContent = text; }
function safeHTML(el, html) { if (el) el.innerHTML = html; }

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

// ✅ 담당자 표시 통일
function formatAssigneeLabel(x) {
  return x.assignee_name
    ? `${x.assignee_name} (@${x.assignee_username || "?"})`
    : (x.assignee_username || x.assignee_id || "-");
}

// ---------------------- LocalStorage ----------------------
function loadUser() {
  try { return JSON.parse(localStorage.getItem("minigit_user") || "null"); }
  catch { return null; }
}
function saveUser(u) {
  state.user = u;
  localStorage.setItem("minigit_user", JSON.stringify(u));
}
function clearUser() {
  state.user = null;
  localStorage.removeItem("minigit_user");
}
function loadToken() { return localStorage.getItem("minigit_token"); }
function saveToken(token) {
  state.token = token;
  localStorage.setItem("minigit_token", token);
}
function clearToken() {
  state.token = null;
  localStorage.removeItem("minigit_token");
}

// ---------------------- Toast ----------------------
function toast(msg, ok = true) {
  const t = $("#toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "toast show " + (ok ? "ok" : "bad");
  setTimeout(() => {
    t.className = "toast";
    t.textContent = "";
  }, 2200);
}

// ---------------------- API Helper ----------------------
async function api(path, options = {}) {
  const token = loadToken();
  const url = `${API_BASE}${path}`;

  // ✅ FormData 업로드 대응: Content-Type은 브라우저가 boundary 포함해서 자동 설정해야 함
  const isFormData = options.body instanceof FormData;

  const res = await fetch(url, {
    headers: {
      ...(isFormData ? {} : { "Content-Type": "application/json" }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
    ...options,
  });

  const data = await res.json().catch(() => ({}));

  if (res.status === 401) {
    clearToken();
    clearUser();

    state.currentProject = null;
    state.currentDocument = null;
    state.projects = [];
    state.documents = [];
    state.versions = [];
    state.tasks = [];
    state.projectMembers = [];

    renderUserHeader();
    resetSelectionUI();
    clearMainPanels();
    openAuth(true);
    showLoginPane();

    throw new Error(data?.message || "인증이 필요합니다. 다시 로그인하세요.");
  }

  if (!res.ok) {
    const msg = data?.message || `요청 실패: ${res.status} (${url})`;
    throw new Error(msg);
  }

  return data;
}

// ---------------------- Modal Helpers ----------------------
function openModal(modalId, open = true) {
  const m = document.getElementById(modalId);
  if (!m) return;
  m.setAttribute("aria-hidden", open ? "false" : "true");
}
function closeAllModals() {
  ["projectModal", "documentModal", "versionModal", "taskModal", "confirmModal"].forEach((id) =>
    openModal(id, false)
  );
}
function initModalClosers() {
  document.addEventListener("click", (e) => {
    const t = e.target;
    const key = t?.dataset?.close;
    if (!key) return;

    if (key === "1") {
      if (!state.user) return;
      openAuth(false);
      return;
    }

    if (key === "project") openModal("projectModal", false);
    if (key === "document") openModal("documentModal", false);
    if (key === "version") openModal("versionModal", false);
    if (key === "task") openModal("taskModal", false);
    if (key === "confirm") openModal("confirmModal", false);
  });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (state.user) openAuth(false);
    closeAllModals();
  });
}

// ✅ confirm 모달 로직
let __confirmHandler = null;
function openConfirm({ title = "확인", message = "", okText = "확인", cancelText = "취소", onConfirm }) {
  safeText($("#confirmTitle"), title);
  safeText($("#confirmMessage"), message);
  safeText($("#confirmOk"), okText);
  safeText($("#confirmCancel"), cancelText);

  __confirmHandler = typeof onConfirm === "function" ? onConfirm : null;
  openModal("confirmModal", true);
}
function initConfirmModal() {
  $("#confirmCancel")?.addEventListener("click", () => openModal("confirmModal", false));
  $("#confirmOk")?.addEventListener("click", async () => {
    const fn = __confirmHandler;
    __confirmHandler = null;
    openModal("confirmModal", false);
    if (fn) await fn();
  });
}

// ---------------------- UI Lock/Unlock ----------------------
function lockMainUI(locked) {
  if ($("#appRoot")) document.body.classList.toggle("locked", locked);
}

function renderUserHeader() {
  const badge = $("#userBadge");
  const btnOpenAuth = $("#btnOpenAuth");
  const btnLogout = $("#btnLogout");

  if (badge) badge.textContent = state.user ? `${state.user.name} (@${state.user.username})` : "Guest";
  if (btnOpenAuth) btnOpenAuth.style.display = state.user ? "none" : "";
  if (btnLogout) btnLogout.style.display = state.user ? "" : "none";

  lockMainUI(!state.user);
  updateQuickActionState();
}

// ---------------------- Auth Modal ----------------------
function openAuth(open = true) {
  const modal = $("#authModal");
  if (!modal) return;
  modal.setAttribute("aria-hidden", open ? "false" : "true");
}
function showLoginPane() {
  $("#loginForm") && ($("#loginForm").style.display = "block");
  $("#registerForm") && ($("#registerForm").style.display = "none");
}
function showRegisterPane() {
  $("#loginForm") && ($("#loginForm").style.display = "none");
  $("#registerForm") && ($("#registerForm").style.display = "block");
}

function initAuth() {
  $("#btnLogout")?.addEventListener("click", () => {
    clearToken();
    clearUser();

    state.currentProject = null;
    state.currentDocument = null;
    state.projects = [];
    state.documents = [];
    state.versions = [];
    state.tasks = [];
    state.projectMembers = [];

    renderUserHeader();
    openAuth(true);
    showLoginPane();
    resetSelectionUI();
    clearMainPanels();
  });

  $("#authModal")?.addEventListener("click", (e) => {
    const t = e.target;
    if (t?.dataset?.close) {
      if (!state.user) return;
      openAuth(false);
    }
  });

  $("#btnOpenAuth")?.addEventListener("click", () => {
    openAuth(true);
    showLoginPane();
  });

  $("#toRegister")?.addEventListener("click", () => {
    showRegisterPane();
    $("#registerForm")?.querySelector('input[name="username"]')?.focus();
  });
  $("#toLogin")?.addEventListener("click", () => {
    showLoginPane();
    $("#loginForm")?.querySelector('input[name="username"]')?.focus();
  });

  $("#loginForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const username = form.querySelector('input[name="username"]')?.value?.trim();
    const password = form.querySelector('input[name="password"]')?.value?.trim();

    try {
      const data = await api("/auth/login", {
        method: "POST",
        body: JSON.stringify({ username, password }),
      });

      if (data.token) saveToken(data.token);

      const u = data.user || data;
      saveUser({ id: u.id, username: u.username, name: u.name || u.username });

      toast("로그인 성공");
      openAuth(false);
      renderUserHeader();
      await refreshCurrentView(true);
    } catch (err) {
      console.error(err);
      toast(err.message || "로그인 실패", false);
    }
  });

  $("#registerForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const username = form.querySelector('input[name="username"]')?.value?.trim();
    const password = form.querySelector('input[name="password"]')?.value?.trim();
    const name = form.querySelector('input[name="name"]')?.value?.trim();

    try {
      await api("/auth/register", {
        method: "POST",
        body: JSON.stringify({ username, password, name }),
      });

      toast("회원가입 성공! 로그인 해주세요.");
      showLoginPane();

      const lu = $("#loginForm")?.querySelector('input[name="username"]');
      const lp = $("#loginForm")?.querySelector('input[name="password"]');
      if (lu) lu.value = username;
      if (lp) lp.value = password;
      lu?.focus();
    } catch (err) {
      console.error(err);
      toast(err.message || "회원가입 실패", false);
    }
  });

  renderUserHeader();
  if (!state.user) {
    openAuth(true);
    showLoginPane();
  }
}

// ---------------------- Navigation / View ----------------------
function initNav() {
  $$(".navbtn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      $$(".navbtn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      state.currentView = btn.dataset.view;
      await refreshCurrentView(false);
    });
  });

  $("#btnRefresh")?.addEventListener("click", () => refreshCurrentView(false));
  $("#search")?.addEventListener("input", () => renderList());
}

// ---------------------- Quick Actions ----------------------
function initQuickActions() {
  $("#btnNewProject")?.addEventListener("click", () => {
    if (!state.user) return openAuth(true);
    openCreateProjectModal();
  });

  $("#btnNewDoc")?.addEventListener("click", () => {
    if (!state.user) return openAuth(true);
    if (!state.currentProject) return toast("프로젝트를 먼저 선택하세요.", false);
    openCreateDocumentModal();
  });

  $("#btnNewVersion")?.addEventListener("click", async () => {
    if (!state.user) return openAuth(true);
    if (!state.currentDocument) return toast("문서를 먼저 선택하세요.", false);
    await openCreateVersionModal();
  });

  $("#btnNewTask")?.addEventListener("click", () => {
    if (!state.user) return openAuth(true);
    if (!state.currentProject) return toast("프로젝트를 먼저 선택하세요.", false);
    openCreateTaskModal();
  });
}

function setViewHeader(title, hint) {
  safeText($("#viewTitle"), title);
  safeText($("#viewHint"), hint);
}

function updateQuickActionState() {
  const p = !!state.currentProject;
  const d = !!state.currentDocument;
  const logged = !!state.user;

  const btnDoc = $("#btnNewDoc");
  const btnVer = $("#btnNewVersion");
  const btnTask = $("#btnNewTask");
  const btnProj = $("#btnNewProject");

  if (btnProj) btnProj.disabled = !logged;
  if (btnDoc) btnDoc.disabled = !logged || !p;
  if (btnTask) btnTask.disabled = !logged || !p;
  if (btnVer) btnVer.disabled = !logged || !d;
}

// ---------------------- Data Loaders ----------------------
async function loadProjects() {
  const data = await api(`/projects`);
  state.projects = data.projects || [];
}
async function loadProjectMembers(projectId) {
  const data = await api(`/projects/${projectId}/members`);
  state.projectMembers = data.members || [];
}
async function loadDocuments(projectId) {
  const data = await api(`/documents/project/${projectId}`);
  state.documents = data.documents || [];
}
async function loadVersions(documentId) {
  const data = await api(`/versions/document/${documentId}`);
  state.versions = data.versions || [];
}
async function loadTasks(projectId) {
  const data = await api(`/tasks/project/${projectId}`);
  state.tasks = data.tasks || [];
}
async function loadStats(projectId) {
  const data = await api(`/stats/project/${projectId}/summary`);
  return data;
}

// ---------------------- Permission Helpers ----------------------
function isProjectOwnerByMembers() {
  const me = state.user?.id;
  if (!me) return false;
  return (state.projectMembers || []).some((m) => m.id === me && m.role === "owner");
}
function canDeleteProject(p) {
  const me = state.user?.id;
  if (!me || !p) return false;
  return p.owner_id === me || isProjectOwnerByMembers();
}
function canDeleteDocument(d) {
  const me = state.user?.id;
  if (!me || !d) return false;
  return d.owner_id === me || canDeleteProject(state.currentProject);
}
function canDeleteTask(t) {
  const me = state.user?.id;
  if (!me || !t) return false;
  return canDeleteProject(state.currentProject) || t.assignee_id === me;
}
function canEditProject(p) { return canDeleteProject(p); }
function canEditDocument(d) { return canDeleteDocument(d); }
function canEditTask(t) { return canDeleteTask(t) || t.assignee_id === state.user?.id; }

// ---------------------- Delete API Wrappers ----------------------
async function deleteProject(projectId) { await api(`/projects/${projectId}`, { method: "DELETE" }); }
async function deleteDocument(docId) { await api(`/documents/${docId}`, { method: "DELETE" }); }
async function deleteTask(taskId) { await api(`/tasks/${taskId}`, { method: "DELETE" }); }

// ✅ Update API Wrappers
async function updateProject(projectId, patch) {
  return await api(`/projects/${projectId}`, { method: "PUT", body: JSON.stringify(patch) });
}
async function updateDocument(docId, patch) {
  return await api(`/documents/${docId}`, { method: "PUT", body: JSON.stringify(patch) });
}
async function updateTask(taskId, patch) {
  return await api(`/tasks/${taskId}`, { method: "PUT", body: JSON.stringify(patch) });
}

// ---------------------- Rendering ----------------------
function resetSelectionUI() {
  safeText($("#selProject"), state.currentProject ? state.currentProject.name : "-");
  safeText($("#selDocument"), state.currentDocument ? state.currentDocument.title : "-");
  updateQuickActionState();
}
function clearMainPanels() {
  safeHTML($("#list"), "");
  safeHTML($("#detail"), `<div class="muted">왼쪽 목록에서 항목을 선택하세요.</div>`);
}
function getSearchKeyword() {
  return ($("#search")?.value || "").trim().toLowerCase();
}

// ✅ list item 오른쪽 액션 버튼(편집/삭제)
function renderListItemActions({ type, item }) {
  const me = state.user?.id;
  let canEdit = false;
  let canDel = false;

  if (type === "project") { canEdit = canEditProject(item); canDel = canDeleteProject(item); }
  if (type === "document") { canEdit = canEditDocument(item); canDel = canDeleteDocument(item); }
  if (type === "task") { canEdit = canEditTask(item); canDel = canDeleteTask(item); }
  if (type === "version") { canEdit = false; canDel = false; }

  const editDisabled = (!me || !canEdit) ? "disabled" : "";
  const delDisabled = (!me || !canDel) ? "disabled" : "";

  return `
    <div class="row" style="justify-content:flex-end; gap:6px; margin-top:8px;">
      <button class="btn ghost js-edit" type="button" ${editDisabled} title="편집">✎</button>
      <button class="btn ghost js-del" type="button" ${delDisabled} title="삭제">🗑</button>
    </div>
  `;
}

function renderList() {
  const listEl = $("#list");
  if (!listEl) return;
  listEl.innerHTML = "";

  const kw = getSearchKeyword();
  let items = [];
  if (state.currentView === "projects") items = state.projects;
  if (state.currentView === "documents") items = state.documents;
  if (state.currentView === "versions") items = state.versions;
  if (state.currentView === "tasks") items = state.tasks;

  if (kw) items = items.filter((x) => JSON.stringify(x).toLowerCase().includes(kw));

  if (!items.length) {
    listEl.innerHTML = `<div class="muted">표시할 항목이 없습니다.</div>`;
    return;
  }

  items.forEach((x) => {
    const div = document.createElement("div");
    div.className = "item";

    if (state.currentView === "projects") {
      div.innerHTML = `
        <div class="row" style="justify-content:space-between; gap:10px;">
          <div class="name">${x.name}</div>
          <div class="meta">id=${x.id}</div>
        </div>
        <div class="meta">${x.description || ""}</div>
        ${renderListItemActions({ type: "project", item: x })}
      `;

      div.addEventListener("click", (e) => {
        if (e.target?.closest(".js-edit") || e.target?.closest(".js-del")) return;
        onSelectProject(x);
      });

      div.querySelector(".js-edit")?.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelectProject(x).then(() => renderProjectEditForm(x));
      });

      div.querySelector(".js-del")?.addEventListener("click", (e) => {
        e.stopPropagation();
        handleDeleteProject(x);
      });
    }

    if (state.currentView === "documents") {
      div.innerHTML = `
        <div class="row" style="justify-content:space-between; gap:10px;">
          <div class="name">${x.title}</div>
          <div class="meta">id=${x.id}</div>
        </div>
        <div class="meta">${x.description || ""}</div>
        ${renderListItemActions({ type: "document", item: x })}
      `;

      div.addEventListener("click", (e) => {
        if (e.target?.closest(".js-edit") || e.target?.closest(".js-del")) return;
        onSelectDocument(x);
      });

      div.querySelector(".js-edit")?.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelectDocument(x).then(() => renderDocumentEditForm(x));
      });

      div.querySelector(".js-del")?.addEventListener("click", (e) => {
        e.stopPropagation();
        handleDeleteDocument(x);
      });
    }

    if (state.currentView === "versions") {
      div.innerHTML = `
        <div class="row"><div class="name">v${x.version_no}</div><div class="meta">id=${x.id}</div></div>
        <div class="meta">author: ${x.author_name || ""} (@${x.author_username || ""}) / ${x.created_at || ""}</div>
        <div class="meta">${x.change_note || ""}</div>
        <div class="meta">${x.file_name ? "📎 " + escapeHtml(x.file_name) : ""}</div>
      `;
      div.addEventListener("click", () => renderVersionDetail(x));
    }

    if (state.currentView === "tasks") {
      const label = formatAssigneeLabel(x);
      div.innerHTML = `
        <div class="row" style="justify-content:space-between; gap:10px;">
          <div class="name">${x.title}</div>
          <div class="meta">[${x.status}] id=${x.id}</div>
        </div>
        <div class="meta">${x.description || ""}</div>
        <div class="meta">assignee: ${label}</div>
        ${renderListItemActions({ type: "task", item: x })}
      `;

      div.addEventListener("click", (e) => {
        if (e.target?.closest(".js-edit") || e.target?.closest(".js-del")) return;
        renderTaskDetail(x);
      });

      div.querySelector(".js-edit")?.addEventListener("click", (e) => {
        e.stopPropagation();
        renderTaskEditForm(x);
      });

      div.querySelector(".js-del")?.addEventListener("click", (e) => {
        e.stopPropagation();
        handleDeleteTask(x);
      });
    }

    listEl.appendChild(div);
  });
}

// ---------------------- Delete Handlers ----------------------
function handleDeleteProject(project) {
  if (!canDeleteProject(project)) return toast("권한이 없습니다.", false);

  openConfirm({
    title: "프로젝트 삭제",
    message: `정말 '${project.name}' 프로젝트를 삭제할까요?\n(연결된 문서/버전/태스크가 같이 삭제될 수 있어요)`,
    okText: "삭제",
    onConfirm: async () => {
      try {
        await deleteProject(project.id);
        toast("프로젝트 삭제 성공");

        state.currentProject = null;
        state.currentDocument = null;
        state.documents = [];
        state.versions = [];
        state.tasks = [];
        state.projectMembers = [];

        await switchView("projects");
      } catch (e) {
        toast(e.message || "삭제 실패", false);
      }
    }
  });
}

function handleDeleteDocument(doc) {
  if (!canDeleteDocument(doc)) return toast("권한이 없습니다.", false);

  openConfirm({
    title: "문서 삭제",
    message: `정말 '${doc.title}' 문서를 삭제할까요?\n(해당 문서의 모든 버전이 함께 삭제될 수 있어요)`,
    okText: "삭제",
    onConfirm: async () => {
      try {
        await deleteDocument(doc.id);
        toast("문서 삭제 성공");

        state.currentDocument = null;
        state.versions = [];
        await switchView("documents");
      } catch (e) {
        toast(e.message || "삭제 실패", false);
      }
    }
  });
}

function handleDeleteTask(t) {
  if (!canDeleteTask(t)) return toast("권한이 없습니다.", false);

  openConfirm({
    title: "태스크 삭제",
    message: `정말 '${t.title}' 태스크를 삭제할까요?`,
    okText: "삭제",
    onConfirm: async () => {
      try {
        await deleteTask(t.id);
        toast("태스크 삭제 성공");
        await switchView("tasks");
      } catch (e) {
        toast(e.message || "삭제 실패", false);
      }
    }
  });
}

// ---------------------- Detail Renderers ----------------------
function renderProjectDetail(project) {
  const el = $("#detail");
  if (!el) return;

  const membersHtml = (state.projectMembers || [])
    .map((m) => `<div class="kv"><span>${m.name} (@${m.username})</span><b>${m.role}</b></div>`)
    .join("");

  const canDel = canDeleteProject(project);
  const canEd = canEditProject(project);

  el.innerHTML = `
    <div class="detail">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <div>
          <div style="font-weight:800; font-size:18px;">${project.name}</div>
          <div class="muted">${project.description || ""}</div>
        </div>
        <div style="display:flex; gap:8px; align-items:center;">
          <button class="btn ghost" id="btnEditProject" type="button" ${canEd ? "" : "disabled"}>✎ 편집</button>
          <button class="btn ghost" id="btnDeleteProject" type="button" ${canDel ? "" : "disabled"}>🗑 삭제</button>
          <button class="btn ghost" id="btnReloadMembers" type="button">멤버 새로고침</button>
        </div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">프로젝트 멤버</div>
        ${membersHtml || `<div class="muted">멤버가 없습니다.</div>`}
      </div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">멤버 추가</div>
        <label class="label">추가할 아이디(username)</label>
        <input class="input" id="memberUsername" type="text" placeholder="예: wlgjs07" autocomplete="off" />

        <label class="label">role (owner/member)</label>
        <select class="select" id="memberRole">
          <option value="member" selected>member</option>
          <option value="owner">owner</option>
        </select>

        <button class="btn full" id="btnAddMemberInline" type="button">+ 추가</button>

        <div class="muted" style="margin-top:8px; font-size:12px;">
          ※ 숫자 id가 아니라, 회원가입할 때 만든 아이디(username)를 입력하세요.
        </div>
      </div>

      <div class="rowbtns">
        <button class="btn" id="btnGoDocuments" type="button">문서 보기</button>
        <button class="btn" id="btnGoTasks" type="button">태스크 보기</button>
        <button class="btn ghost" id="btnGoStats" type="button">통계 보기</button>
      </div>
    </div>
  `;

  $("#btnReloadMembers")?.addEventListener("click", async () => {
    try {
      await loadProjectMembers(project.id);
      renderProjectDetail(project);
    } catch (e) { toast(e.message, false); }
  });

  $("#btnAddMemberInline")?.addEventListener("click", async () => {
    const username = ($("#memberUsername")?.value || "").trim();
    const role = $("#memberRole")?.value || "member";
    if (!username) return toast("아이디(username)를 입력하세요.", false);

    try {
      await api(`/projects/${project.id}/members`, {
        method: "POST",
        body: JSON.stringify({ username, role }),
      });

      toast("멤버 추가 성공");
      $("#memberUsername").value = "";
      await loadProjectMembers(project.id);
      renderProjectDetail(project);
    } catch (err) {
      console.error(err);
      toast(err.message || "멤버 추가 실패", false);
    }
  });

  $("#btnEditProject")?.addEventListener("click", () => renderProjectEditForm(project));
  $("#btnDeleteProject")?.addEventListener("click", () => handleDeleteProject(project));

  // ✅ 버튼으로만 이동
  $("#btnGoDocuments")?.addEventListener("click", async () => switchView("documents"));
  $("#btnGoTasks")?.addEventListener("click", async () => switchView("tasks"));
  $("#btnGoStats")?.addEventListener("click", async () => switchView("stats"));
}

function renderDocumentDetail(doc) {
  const el = $("#detail");
  if (!el) return;

  const canDel = canDeleteDocument(doc);
  const canEd = canEditDocument(doc);

  el.innerHTML = `
    <div class="detail">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <div>
          <div style="font-weight:800; font-size:18px;">${doc.title}</div>
          <div class="muted">${doc.description || ""}</div>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn ghost" id="btnEditDocument" type="button" ${canEd ? "" : "disabled"}>✎ 편집</button>
          <button class="btn ghost" id="btnDeleteDocument" type="button" ${canDel ? "" : "disabled"}>🗑 삭제</button>
        </div>
      </div>

      <div class="rowbtns">
        <button class="btn" id="btnGoVersions" type="button">버전 보기</button>
        <button class="btn ghost" id="btnCreateVersion" type="button">+ 버전 업로드</button>
      </div>
    </div>
  `;

  $("#btnGoVersions")?.addEventListener("click", async () => switchView("versions"));
  $("#btnCreateVersion")?.addEventListener("click", async () => openCreateVersionModal());

  $("#btnEditDocument")?.addEventListener("click", () => renderDocumentEditForm(doc));
  $("#btnDeleteDocument")?.addEventListener("click", () => handleDeleteDocument(doc));
}

// ✅ 미리보기 HTML 생성
function buildPreviewHtml(v) {
  if (!v.file_path) return `<div class="muted">(업로드 파일 없음)</div>`;

  const url = `${API_BASE}${v.file_path}`;
  const t = (v.file_type || "").toLowerCase();

  if (t.startsWith("image/")) {
    return `<img src="${escapeHtml(url)}" alt="preview" style="max-width:100%; border-radius:10px;" />`;
  }

  if (t === "application/pdf") {
    return `<iframe src="${escapeHtml(url)}" style="width:100%; height:520px; border:1px solid rgba(255,255,255,.15); border-radius:10px;"></iframe>`;
  }

  if (t.startsWith("text/") || t.includes("json") || t.includes("xml") || t.includes("csv")) {
    return `
      <div class="muted" style="margin-bottom:6px;">텍스트 파일 미리보기는 상단 '텍스트 로드' 버튼을 눌러주세요.</div>
      <pre id="txtPreview" class="muted" style="white-space:pre-wrap; max-height:420px; overflow:auto; border:1px solid rgba(255,255,255,.15); padding:10px; border-radius:10px;"></pre>
      <div class="row" style="justify-content:flex-end; gap:8px; margin-top:10px;">
        <button class="btn ghost" id="btnLoadText" type="button">텍스트 로드</button>
      </div>
    `;
  }

  return `<div class="muted">미리보기를 지원하지 않는 파일 형식입니다. 다운로드로 확인하세요.</div>`;
}

function renderVersionDetail(v) {
  const el = $("#detail");
  if (!el) return;

  const fileUrl = v.file_path ? `${API_BASE}${v.file_path}` : "";

  el.innerHTML = `
    <div class="detail">
      <div style="font-weight:800; font-size:18px;">v${v.version_no}</div>
      <div class="muted">author: ${v.author_name || ""} (@${v.author_username || ""}) / ${v.created_at || ""}</div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">change_note</div>
        <div>${v.change_note || "(없음)"}</div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">content</div>
        <div class="muted" style="white-space:pre-wrap;">${escapeHtml((v.content || "").slice(0, 3000))}</div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">파일</div>
        <div class="meta">${v.file_name ? "📎 " + escapeHtml(v.file_name) : "(없음)"}</div>
        <div class="row" style="justify-content:flex-end; gap:8px; margin-top:8px;">
          ${fileUrl ? `<a class="btn ghost" href="${escapeHtml(fileUrl)}" download>⬇ 다운로드</a>` : ""}
          ${fileUrl ? `<a class="btn ghost" href="${escapeHtml(fileUrl)}" target="_blank" rel="noreferrer">↗ 새창</a>` : ""}
        </div>

        <div style="margin-top:12px;">
          ${buildPreviewHtml(v)}
        </div>
      </div>
    </div>
  `;

  $("#btnLoadText")?.addEventListener("click", async () => {
    if (!v.file_path) return;
    try {
      const url = `${API_BASE}${v.file_path}`;
      const res = await fetch(url);
      const txt = await res.text();
      const pre = $("#txtPreview");
      if (pre) pre.textContent = txt.slice(0, 30000);
    } catch (e) {
      toast("텍스트 로드 실패", false);
    }
  });
}

function renderTaskDetail(t) {
  const el = $("#detail");
  if (!el) return;

  const label = formatAssigneeLabel(t);
  const canDel = canDeleteTask(t);
  const canEd = canEditTask(t);

  el.innerHTML = `
    <div class="detail">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <div>
          <div style="font-weight:800; font-size:18px;">${t.title}</div>
          <div class="muted">status=${t.status} / id=${t.id}</div>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn ghost" id="btnEditTask" type="button" ${canEd ? "" : "disabled"}>✎ 편집</button>
          <button class="btn ghost" id="btnDeleteTask" type="button" ${canDel ? "" : "disabled"}>🗑 삭제</button>
        </div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">description</div>
        <div>${t.description || "(없음)"}</div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <div class="panel-title">assignee</div>
        <div>${label}</div>
      </div>
    </div>
  `;

  $("#btnEditTask")?.addEventListener("click", () => renderTaskEditForm(t));
  $("#btnDeleteTask")?.addEventListener("click", () => handleDeleteTask(t));
}

// ---------------------- Edit Forms (Detail Panel) ----------------------
function renderProjectEditForm(project) {
  const el = $("#detail");
  if (!el) return;
  if (!canEditProject(project)) return toast("권한이 없습니다.", false);

  el.innerHTML = `
    <div class="detail">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <div style="font-weight:800; font-size:18px;">프로젝트 편집</div>
        <div style="display:flex; gap:8px;">
          <button class="btn ghost" id="btnCancelEditProject" type="button">취소</button>
          <button class="btn" id="btnSaveEditProject" type="button">저장</button>
        </div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <label class="label">이름</label>
        <input class="input" id="editProjectName" value="${escapeHtml(project.name || "")}" />
        <label class="label">설명</label>
        <textarea class="textarea" id="editProjectDesc">${escapeHtml(project.description || "")}</textarea>
        <div class="muted" style="margin-top:8px; font-size:12px;">id=${project.id}</div>
      </div>
    </div>
  `;

  $("#btnCancelEditProject")?.addEventListener("click", async () => {
    await loadProjectMembers(project.id).catch(() => {});
    renderProjectDetail(project);
  });

  $("#btnSaveEditProject")?.addEventListener("click", async () => {
    const name = ($("#editProjectName")?.value || "").trim();
    const description = ($("#editProjectDesc")?.value || "").trim();
    if (!name) return toast("프로젝트 이름은 필수입니다.", false);

    try {
      await updateProject(project.id, { name, description });
      toast("프로젝트 수정 성공");

      await loadProjects();
      const updated = state.projects.find((p) => p.id === project.id) || { ...project, name, description };
      state.currentProject = updated;

      renderList();
      await loadProjectMembers(updated.id).catch(() => {});
      renderProjectDetail(updated);
      resetSelectionUI();
    } catch (e) {
      toast(e.message || "수정 실패", false);
    }
  });
}

function renderDocumentEditForm(doc) {
  const el = $("#detail");
  if (!el) return;
  if (!canEditDocument(doc)) return toast("권한이 없습니다.", false);

  el.innerHTML = `
    <div class="detail">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <div style="font-weight:800; font-size:18px;">문서 편집</div>
        <div style="display:flex; gap:8px;">
          <button class="btn ghost" id="btnCancelEditDoc" type="button">취소</button>
          <button class="btn" id="btnSaveEditDoc" type="button">저장</button>
        </div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <label class="label">제목</label>
        <input class="input" id="editDocTitle" value="${escapeHtml(doc.title || "")}" />
        <label class="label">설명</label>
        <textarea class="textarea" id="editDocDesc">${escapeHtml(doc.description || "")}</textarea>
        <div class="muted" style="margin-top:8px; font-size:12px;">id=${doc.id}</div>
      </div>
    </div>
  `;

  $("#btnCancelEditDoc")?.addEventListener("click", () => renderDocumentDetail(doc));

  $("#btnSaveEditDoc")?.addEventListener("click", async () => {
    const title = ($("#editDocTitle")?.value || "").trim();
    const description = ($("#editDocDesc")?.value || "").trim();
    if (!title) return toast("문서 제목은 필수입니다.", false);

    try {
      await updateDocument(doc.id, { title, description });
      toast("문서 수정 성공");

      await loadDocuments(state.currentProject.id);
      const updated = state.documents.find((d) => d.id === doc.id) || { ...doc, title, description };
      state.currentDocument = updated;

      renderList();
      renderDocumentDetail(updated);
      resetSelectionUI();
    } catch (e) {
      toast(e.message || "수정 실패", false);
    }
  });
}

function renderTaskEditForm(t) {
  const el = $("#detail");
  if (!el) return;
  if (!canEditTask(t)) return toast("권한이 없습니다.", false);

  const currentAssignee = t.assignee_username || "";

  el.innerHTML = `
    <div class="detail">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:10px;">
        <div style="font-weight:800; font-size:18px;">태스크 편집</div>
        <div style="display:flex; gap:8px;">
          <button class="btn ghost" id="btnCancelEditTask" type="button">취소</button>
          <button class="btn" id="btnSaveEditTask" type="button">저장</button>
        </div>
      </div>

      <div class="panel" style="margin-top:12px;">
        <label class="label">제목</label>
        <input class="input" id="editTaskTitle" value="${escapeHtml(t.title || "")}" />

        <label class="label">설명</label>
        <textarea class="textarea" id="editTaskDesc">${escapeHtml(t.description || "")}</textarea>

        <label class="label">상태 (todo/doing/done)</label>
        <select class="select" id="editTaskStatus">
          <option value="todo" ${t.status === "todo" ? "selected" : ""}>todo</option>
          <option value="doing" ${t.status === "doing" ? "selected" : ""}>doing</option>
          <option value="done" ${t.status === "done" ? "selected" : ""}>done</option>
        </select>

        <label class="label">담당자 username (비우면 해제)</label>
        <input class="input" id="editTaskAssignee" value="${escapeHtml(currentAssignee)}" placeholder="예: wlgjs07" />

        <div class="muted" style="margin-top:8px; font-size:12px;">
          ※ 담당자는 프로젝트 멤버(username)만 가능 (백엔드가 검증)
        </div>
        <div class="muted" style="margin-top:6px; font-size:12px;">id=${t.id}</div>
      </div>
    </div>
  `;

  $("#btnCancelEditTask")?.addEventListener("click", () => renderTaskDetail(t));

  $("#btnSaveEditTask")?.addEventListener("click", async () => {
    const title = ($("#editTaskTitle")?.value || "").trim();
    const description = ($("#editTaskDesc")?.value || "").trim();
    const status = ($("#editTaskStatus")?.value || "todo").trim();
    const assignee_username = ($("#editTaskAssignee")?.value || "").trim();

    if (!title) return toast("태스크 제목은 필수입니다.", false);

    try {
      const patch = { title, description, status, assignee_username };
      await updateTask(t.id, patch);
      toast("태스크 수정 성공");

      await loadTasks(state.currentProject.id);
      const updated = state.tasks.find((x) => x.id === t.id) || { ...t, title, description, status, assignee_username };
      renderList();
      renderTaskDetail(updated);
    } catch (e) {
      toast(e.message || "수정 실패", false);
    }
  });
}

// ---------------------- Selection Handlers ----------------------
async function onSelectProject(p) {
  state.currentProject = p;
  state.currentDocument = null;

  state.documents = [];
  state.tasks = [];
  state.versions = [];

  resetSelectionUI();

  try { await loadProjectMembers(p.id); } catch { state.projectMembers = []; }

  // ✅ 상세를 그리고 끝 (자동 화면이동 제거)
  renderProjectDetail(p);
}

async function onSelectDocument(d) {
  state.currentDocument = d;
  state.versions = [];
  resetSelectionUI();

  // ✅ 상세를 그리고 끝 (자동 화면이동 제거)
  renderDocumentDetail(d);
}

// ---------------------- View Switch ----------------------
async function switchView(view) {
  state.currentView = view;
  $$(".navbtn").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  await refreshCurrentView(false);
}

function setDetailIfEmpty(html) {
  const el = $("#detail");
  if (!el) return;
  if (!el.innerHTML || !el.innerHTML.trim()) safeHTML(el, html);
}

async function refreshCurrentView(resetDetail = false) {
  if (!state.user) return;

  if (state.currentView === "projects") {
    setViewHeader("프로젝트", "내가 속한 프로젝트 목록을 불러옵니다.");
  } else if (state.currentView === "documents") {
    setViewHeader("문서", state.currentProject ? "선택한 프로젝트의 문서 목록입니다." : "프로젝트를 먼저 선택하세요.");
  } else if (state.currentView === "versions") {
    setViewHeader("버전", state.currentDocument ? "선택한 문서의 버전 목록입니다." : "문서를 먼저 선택하세요.");
  } else if (state.currentView === "tasks") {
    setViewHeader("태스크", state.currentProject ? "선택한 프로젝트의 태스크 목록입니다." : "프로젝트를 먼저 선택하세요.");
  } else if (state.currentView === "stats") {
    setViewHeader("통계", state.currentProject ? "선택한 프로젝트 통계입니다." : "프로젝트를 먼저 선택하세요.");
  }

  if (resetDetail) clearMainPanels();
  resetSelectionUI();

  try {
    if (state.currentView === "projects") {
      await loadProjects();
      renderList();

      if (resetDetail) {
        safeHTML($("#detail"), `<div class="muted">프로젝트를 선택하세요.</div>`);
      } else {
        // ✅ 선택된 프로젝트가 있으면 그 상세 유지/재렌더
        if (state.currentProject) renderProjectDetail(state.currentProject);
        else setDetailIfEmpty(`<div class="muted">프로젝트를 선택하세요.</div>`);
      }
      return;
    }

    if (state.currentView === "documents") {
      if (!state.currentProject) {
        safeHTML($("#list"), `<div class="muted">프로젝트를 먼저 선택하세요.</div>`);
        if (resetDetail) safeHTML($("#detail"), `<div class="muted">프로젝트를 선택하세요.</div>`);
        return;
      }
      await loadDocuments(state.currentProject.id);
      renderList();

      if (resetDetail) {
        safeHTML($("#detail"), `<div class="muted">문서를 선택하세요.</div>`);
      } else {
        if (state.currentDocument) renderDocumentDetail(state.currentDocument);
        else setDetailIfEmpty(`<div class="muted">문서를 선택하세요.</div>`);
      }
      return;
    }

    if (state.currentView === "versions") {
      if (!state.currentDocument) {
        safeHTML($("#list"), `<div class="muted">문서를 먼저 선택하세요.</div>`);
        if (resetDetail) safeHTML($("#detail"), `<div class="muted">문서를 선택하세요.</div>`);
        return;
      }
      await loadVersions(state.currentDocument.id);
      renderList();
      if (resetDetail) safeHTML($("#detail"), `<div class="muted">버전을 선택하세요.</div>`);
      else setDetailIfEmpty(`<div class="muted">버전을 선택하세요.</div>`);
      return;
    }

    if (state.currentView === "tasks") {
      if (!state.currentProject) {
        safeHTML($("#list"), `<div class="muted">프로젝트를 먼저 선택하세요.</div>`);
        if (resetDetail) safeHTML($("#detail"), `<div class="muted">프로젝트를 선택하세요.</div>`);
        return;
      }
      await loadTasks(state.currentProject.id);
      renderList();
      if (resetDetail) safeHTML($("#detail"), `<div class="muted">태스크를 선택하세요.</div>`);
      else setDetailIfEmpty(`<div class="muted">태스크를 선택하세요.</div>`);
      return;
    }

    if (state.currentView === "stats") {
      if (!state.currentProject) {
        safeHTML($("#list"), `<div class="muted">프로젝트를 먼저 선택하세요.</div>`);
        if (resetDetail) safeHTML($("#detail"), `<div class="muted">프로젝트를 선택하세요.</div>`);
        return;
      }
      const data = await loadStats(state.currentProject.id);
      safeHTML($("#list"), `<div class="muted">통계는 오른쪽 상세 패널에서 확인합니다.</div>`);
      safeHTML($("#detail"), `<pre class="muted" style="white-space:pre-wrap;">${escapeHtml(JSON.stringify(data, null, 2))}</pre>`);
      return;
    }
  } catch (err) {
    console.error(err);
    toast(err.message || "불러오기 실패", false);
  }
}

// ---------------------- Create Modals ----------------------
function openCreateProjectModal() {
  const form = $("#projectCreateForm");
  if (form) form.reset();
  openModal("projectModal", true);
  setTimeout(() => form?.querySelector('input[name="name"]')?.focus(), 0);
}
function openCreateDocumentModal() {
  const form = $("#documentCreateForm");
  if (form) form.reset();
  openModal("documentModal", true);
  setTimeout(() => form?.querySelector('input[name="title"]')?.focus(), 0);
}

async function openCreateVersionModal() {
  const form = $("#versionCreateForm");
  if (form) form.reset();

  // ✅ task 목록 로딩 + select 채우기
  if (state.currentProject) {
    await loadTasks(state.currentProject.id).catch(() => {});
    const sel = $("#versionTaskSelect");
    if (sel) {
      sel.innerHTML = `<option value="">태스크를 선택하세요</option>`;
      (state.tasks || []).forEach((t) => {
        const opt = document.createElement("option");
        opt.value = String(t.id);
        opt.textContent = `[${t.status}] ${t.title} (id=${t.id})`;
        sel.appendChild(opt);
      });
    }
  }

  openModal("versionModal", true);
  setTimeout(() => form?.querySelector('select[name="task_id"]')?.focus(), 0);
}

function openCreateTaskModal() {
  const form = $("#taskCreateForm");
  if (form) form.reset();
  openModal("taskModal", true);
  setTimeout(() => form?.querySelector('input[name="title"]')?.focus(), 0);
}

function setSubmitting(form, submitting) {
  const btn = form?.querySelector('button[type="submit"]');
  if (!btn) return;
  btn.disabled = submitting;
  btn.dataset._label ||= btn.textContent;
  btn.textContent = submitting ? "처리중..." : btn.dataset._label;
}

function initCreateForms() {
  $("#projectCreateForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!state.user) return openAuth(true);

    const form = e.currentTarget;
    const name = form.querySelector('input[name="name"]')?.value?.trim();
    const description = form.querySelector('textarea[name="description"]')?.value?.trim() || "";
    if (!name) return toast("프로젝트 이름은 필수입니다.", false);

    try {
      setSubmitting(form, true);
      await api("/projects", {
        method: "POST",
        body: JSON.stringify({ name, description, owner_id: state.user.id }),
      });

      toast("프로젝트 생성 성공");
      openModal("projectModal", false);
      await switchView("projects");
    } catch (err) {
      console.error(err);
      toast(err.message || "프로젝트 생성 실패", false);
    } finally {
      setSubmitting(form, false);
    }
  });

  $("#documentCreateForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!state.user) return openAuth(true);
    if (!state.currentProject) return toast("프로젝트를 먼저 선택하세요.", false);

    const form = e.currentTarget;
    const title = form.querySelector('input[name="title"]')?.value?.trim();
    const description = form.querySelector('textarea[name="description"]')?.value?.trim() || "";
    if (!title) return toast("문서 제목은 필수입니다.", false);

    try {
      setSubmitting(form, true);
      await api("/documents", {
        method: "POST",
        body: JSON.stringify({
          project_id: state.currentProject.id,
          title,
          description,
          owner_id: state.user.id,
        }),
      });

      toast("문서 생성 성공");
      openModal("documentModal", false);
      await switchView("documents");
    } catch (err) {
      console.error(err);
      toast(err.message || "문서 생성 실패", false);
    } finally {
      setSubmitting(form, false);
    }
  });

  // ✅ 버전 업로드(=커밋): FormData + task_id 필수 + change_note 필수 + file 필수
  $("#versionCreateForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!state.user) return openAuth(true);
    if (!state.currentDocument) return toast("문서를 먼저 선택하세요.", false);
    if (!state.currentProject) return toast("프로젝트를 먼저 선택하세요.", false);

    const form = e.currentTarget;
    const task_id = form.querySelector('select[name="task_id"]')?.value?.trim();
    const change_note = form.querySelector('input[name="change_note"]')?.value?.trim() || "";
    const content = form.querySelector('textarea[name="content"]')?.value?.trim() || "";
    const fileInput = form.querySelector('input[name="file"]');

    if (!task_id) return toast("태스크 선택은 필수입니다.", false);
    if (!change_note) return toast("change_note(커밋 메시지)는 필수입니다.", false);
    if (!fileInput || !fileInput.files || !fileInput.files[0]) return toast("파일은 필수입니다.", false);

    try {
      setSubmitting(form, true);

      const fd = new FormData();
      fd.append("task_id", String(task_id));
      fd.append("change_note", change_note);
      fd.append("content", content);
      fd.append("file", fileInput.files[0]);

      await api(`/documents/${state.currentDocument.id}/upload`, {
        method: "POST",
        body: fd,
      });

      toast("버전 업로드 성공");
      openModal("versionModal", false);
      await switchView("versions");
    } catch (err) {
      console.error(err);
      toast(err.message || "버전 업로드 실패", false);
    } finally {
      setSubmitting(form, false);
    }
  });

  $("#taskCreateForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!state.user) return openAuth(true);
    if (!state.currentProject) return toast("프로젝트를 먼저 선택하세요.", false);

    const form = e.currentTarget;
    const title = form.querySelector('input[name="title"]')?.value?.trim();
    const description = form.querySelector('textarea[name="description"]')?.value?.trim() || "";
    const assignee_username = form.querySelector('input[name="assignee_username"]')?.value?.trim() || "";
    if (!title) return toast("태스크 제목은 필수입니다.", false);

    try {
      setSubmitting(form, true);
      const body = { project_id: state.currentProject.id, title, description };
      if (assignee_username) body.assignee_username = assignee_username;

      await api("/tasks", { method: "POST", body: JSON.stringify(body) });

      toast("태스크 생성 성공");
      openModal("taskModal", false);
      await switchView("tasks");
    } catch (err) {
      console.error(err);
      toast(err.message || "태스크 생성 실패", false);
    } finally {
      setSubmitting(form, false);
    }
  });
}

// ---------------------- Boot ----------------------
document.addEventListener("DOMContentLoaded", () => {
  initAuth();
  initNav();
  initQuickActions();
  initModalClosers();
  initConfirmModal();
  initCreateForms();

  resetSelectionUI();
  clearMainPanels();

  if (state.user && !state.token) {
    toast("세션이 만료되었습니다. 다시 로그인하세요.", false);
    clearUser();
    renderUserHeader();
    openAuth(true);
    showLoginPane();
    return;
  }

  if (state.user) {
    refreshCurrentView(true).catch(() => {});
  }
});
